
$(function() {


	const modoOscuroGuardado = localStorage.getItem("modoOscuro");
	const modoOscuroInicial = modoOscuroGuardado ? (modoOscuroGuardado === "true") : prefersDarkMode();

	if (modoOscuroInicial) {
		$('body, .p__sinInformacion').addClass('modo-oscuro');
		$('.inmueble-card, .iconPropiedad').addClass('modo-oscuro-2');
	} else {
		$('body, .p__sinInformacion').removeClass('modo-oscuro');
		$('.inmueble-card, .iconPropiedad').removeClass('modo-oscuro-2');
	}

	$('#toggleModoOscuro').on('click', function() {
		const modoOscuroActual = $('body').hasClass('modo-oscuro');
		$('body, .p__sinInformacion').toggleClass('modo-oscuro', !modoOscuroActual);
		$('.inmueble-card, .iconPropiedad').toggleClass('modo-oscuro-2', !modoOscuroActual);

		localStorage.setItem("modoOscuro", !modoOscuroActual);
	});

	function prefersDarkMode() {
		return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
	}


	$("#formContacto").on("submit", function(e) {
		e.preventDefault();
		let isValid = true;
		let currentDate = new Date();
		let inputDate = new Date($("#fechaContactoClt").val());
		let tomorrow = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000);

		$(".formulario__input, .formulario__textarea").each(function() {
			if ($.trim($(this).val()) === "") {
				isValid = false;
				$(this).css("border-color", "red");
			} else {
				$(this).css("border-color", "");
			}
		});

		// Validar que el nombre no contenga números
		let nombre = $("#nombreClt").val();
		let noNumbersRegex = /^[^0-9]*$/;

		if (!noNumbersRegex.test(nombre)) {
			isValid = false;
			$("#nombreClt").css("border-color", "red");
		}

		// Validar que el correo sea un correo electrónico
		let correo = $("#emailClt").val();
		let emailRegex = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,4})+$/;

		if (emailRegex.test(correo)) {
			isValid = false;
			$("#emailClt").css("border-color", "red");
		}

		// Validar que el teléfono sea un número
		let telefono = $("#telefonoClt").val();
		if (isNaN(telefono)) {
			isValid = false;
			$("#telefonoClt").css("border-color", "red");
		}


		// Validar que el precio no sea un número negativo
		var precio = $("#precioPresupuestoClt").val();
		if (precio < 0) {
			isValid = false;
			$("#precioPresupuestoClt").css("border-color", "red");
		}

		// Validar que la fecha no sea menor que la fecha actual
		if (inputDate < tomorrow) {
			isValid = false;
			$("#fechaContactoClt").css("border-color", "red");
			alert(
				"Por favor, verifica que la fecha de contacto sea minímo un día despúes de la fecha actual ."
			);
		}

		if (isValid == false) {
			alert(
				"Por favor, verifica que todos los campos estén correctamente llenados."
			);
		} else {
			alert("Hemos recibido tu mensaje correctamente. Te contactaremos pronto.");
			this.submit();
		}
	});

	$(".formulario__input, .formulario__textarea ").on("input", function() {
		$(this).css("border-color", "");
	});




	$("#formVendedor").submit(function(e) {
		e.preventDefault();

		let regexNombre = /^[a-zA-Z ñÑ]+$/;
		let regexTelefono = /^[0-9]+$/;
		let regexEmail = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;

		if (
			!regexNombre.test($("#primerNombreVdr").val()) ||
			!regexNombre.test($("#primerApellidoVdr").val()) ||
			!regexNombre.test($("#segundoApellidoVdr").val()) ||
			!regexTelefono.test($("#telefonoVdr").val()) ||
			!regexEmail.test($("#emailVdr").val())
		) {
			if (!regexNombre.test($("#primerNombreVdr").val())) {
				$("#primerNombreVdr").css("border", "1px solid red");
			}
			if (!regexNombre.test($("#segundoNombreVdr").val())) {
				$("#segundoNombreVdr").css("border", "1px solid red");
			}
			if (!regexNombre.test($("#primerApellidoVdr").val())) {
				$("#primerApellidoVdr").css("border", "1px solid red");
			}
			if (!regexNombre.test($("#segundoApellidoVdr").val())) {
				$("#segundoApellidoVdr").css("border", "1px solid red");
			}
			if (!regexTelefono.test($("#telefonoVdr").val())) {
				$("#telefonoVdr").css("border", "1px solid red");
			}
			if (!regexEmail.test($("#emailVdr").val())) {
				$("#emailVdr").css("border", "1px solid red");
			}
			alert(
				"Por favor, verifica que todos los campos estén correctamente llenados."
			);
			return false;

		}

		alert("Se ha guardado exitosamente el vendedor.");
		this.submit();
	});

	// Cuando el usuario cambia el valor de los inputs, reseteamos los estilos
	$(
		"#primerNombreVdr, #segundoNombreVdr, #primerApellidoVdr, #segundoApellidoVdr, #telefonoVdr, #emailVdr"
	).change(function() {
		$(this).css("border", "");
	});

	$("#formCrearPropiedad").submit(function(e) {
		e.preventDefault();

		var titulo = $("#tituloPrd");
		var precio = $("#precioPrd");
		var direccion = $("#direccionPrd");
		var descripcionBreve = $("#descripcionBrevePrd");
		var descripcionCompleta = $("#descripcionCompletaPrd");
		var habitaciones = $("#numHabitacionesPrd");
		var banos = $("#numBanosPrd");
		var estacionamiento = $("#numGarajesPrd");
		var areaInmueble = $("#areaInmueblePrd");
		var areaLote = $("#areaLotePrd");
		var imagen = $("#imagenPrd");

		var inputs = [
			titulo,
			precio,
			direccion,
			descripcionBreve,
			descripcionCompleta,
			habitaciones,
			banos,
			estacionamiento,
			areaInmueble,
			areaLote,
			imagen
		];

		var formValido = true;


		inputs.forEach(function(input) {
			if (
				input.val() == "" ||
				(input.attr("type") == "number" && input.val() <= 0)
			) {
				input.css("border", "1px solid red");
				formValido = false;
			}
		});

		if (!formValido) {
			alert(
				"Por favor, verifica que todos los campos estén correctamente llenados."
			);
			return false;
		}

		// Si todo está bien, puedes enviar el formulario.
		alert("Se ha guardado exitosamente la propiedad.");

		this.submit();
	});


});

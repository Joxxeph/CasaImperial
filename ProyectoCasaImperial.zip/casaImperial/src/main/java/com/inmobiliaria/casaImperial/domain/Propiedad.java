package com.inmobiliaria.casaImperial.domain;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Clase de entidad que representa una propiedad.
 * Anotada con las anotaciones de Lombok (@Data) para la generacion automatica de metodos getter, setter, toString, equals, y hashCode.
 * Anotada con JPA para la persistencia en la base de datos.
 * Implementa la interfaz Serializable para soportar la serializacion.
 */
@Data
@Entity
@Table(name="propiedad")
public class Propiedad implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idPropiedad;
	
	
	@NotEmpty
	private String tituloPrd;
	
	@NotEmpty
	private String precioPrd;
	
	@NotEmpty
	private String tipoInmueblePrd;
	
	@NotEmpty
	private String ciudadPrd;
	
	@NotEmpty
	private String direccionPrd;
	
	@NotEmpty
	private String descripcionBrevePrd;
	
	@NotEmpty
	private String descripcionCompletaPrd;

	
	private String imagenPrd;
	
	@Min(0)
	private int numHabitacionesPrd;
	
	@Min(0)
	private int numBanosPrd;
	
	@Min(0)
	private int numGarajesPrd;
	
	@Min(0)
	private double areaInmueblePrd;
	
	@Min(0)
	private double areaLotePrd;
	
	@Min(0)
	private int idVendedorPrd;
	
	
}


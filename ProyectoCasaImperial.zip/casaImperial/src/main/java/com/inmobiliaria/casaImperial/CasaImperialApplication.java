package com.inmobiliaria.casaImperial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase inicializadora SpringBoot.
 * Esta clase contiene el metodo principal `main` que inicia la aplicacion Spring Boot.
 * @author JosephGutierrez
 */
@SpringBootApplication
public class CasaImperialApplication {

    /**
     * Metodo principal que inicia la aplicacion Spring Boot.
     * @param args Argumentos de linea de comandos (no se utilizan en este caso).
     */
    public static void main(String[] args) {
        SpringApplication.run(CasaImperialApplication.class, args);
    }

}



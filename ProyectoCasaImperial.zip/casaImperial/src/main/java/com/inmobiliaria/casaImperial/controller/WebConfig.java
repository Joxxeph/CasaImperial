
package com.inmobiliaria.casaImperial.controller;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * Clase de configuracion para la internacionalizacion (i18n) en la aplicacion web.
 * Configura el manejo de idiomas y la resolucion de locales.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

	
	
	
	
	@Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:messages");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }
    /**
     * Configura el resolver de localizacion basado en la sesion.
     *
     * @return El bean del resolver de localizacion.
     */
    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver slr = new SessionLocaleResolver();
        slr.setDefaultLocale(new Locale("es")); // Establece el idioma predeterminado como espanol.
        return slr;
    }

    /**
     * Configura el interceptor de cambio de idioma.
     *
     * @return El bean del interceptor de cambio de idioma.
     */
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
        lci.setParamName("lang"); // Define el nombre del parámetro que se utilizará para cambiar el idioma.
        return lci;
    }

    /**
     * Agrega el interceptor de cambio de idioma al registro de interceptores.
     *
     * @param registry El registro de interceptores.
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor());
    }
}



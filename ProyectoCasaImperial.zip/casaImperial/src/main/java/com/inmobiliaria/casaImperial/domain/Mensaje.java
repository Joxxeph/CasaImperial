


package com.inmobiliaria.casaImperial.domain;

import java.io.Serializable;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Clase de entidad que representa un mensaje de cliente.
 * Anotada con las anotaciones de Lombok (@Data) para la generacion automatica de metodos getter, setter, toString, equals, y hashCode.
 * Anotada con JPA para la persistencia en la base de datos.
 * Implementa la interfaz Serializable para soportar la serializacion.
 */
@Data
@Entity
@Table(name="mensajecliente")
public class Mensaje implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idMensajeClt;
	
	
	
	
	@NotEmpty
	private String nombreClt;
	
	@NotEmpty
	@Email
	private String emailClt;
	
	@NotEmpty
	private String telefonoClt;
	
	@NotEmpty
	private String mensajeClt;
	
	@NotEmpty
	private String interesClt;
	
	@NotNull
	private double precioPresupuestoClt;
	
	@NotEmpty
	private String metodoContactoClt;
	
	@NotEmpty
	private String fechaContactoClt;
	
	@NotEmpty
	private String horaContactoClt;
	
	

}


package com.inmobiliaria.casaImperial.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inmobiliaria.casaImperial.domain.Mensaje;
import com.inmobiliaria.casaImperial.domain.Propiedad;
import com.inmobiliaria.casaImperial.repository.PropiedadRepository;



/**
 * Clase de servicio que implementa la interfaz PropiedadService.
 * Proporciona logica de negocio para operaciones relacionadas con la entidad Propiedad.
 */
@Service
public class IPropiedadService implements PropiedadService {

    private final PropiedadRepository propiedadRepository;

    @Autowired
    public IPropiedadService(PropiedadRepository propiedadRepository) {
        this.propiedadRepository = propiedadRepository;
    }

    /**
     * Recupera y devuelve la lista de todas las propiedades almacenadas en la base de datos.
     *
     * @return Lista de propiedades.
     */
    @Override
    @Transactional(readOnly=true)
    public List<Propiedad> listarPropiedades() {
        return (List<Propiedad>) propiedadRepository.findAll();
    }

    /**
     * Guarda una nueva propiedad en la base de datos o actualiza una existente.
     *
     * @param propiedad La propiedad a ser guardada.
     */
    @Override
    @Transactional
    public void guardarPropiedad(Propiedad propiedad) {
        propiedadRepository.save(propiedad);
    }

    /**
     * Elimina una propiedad de la base de datos.
     *
     * @param propiedad La propiedad a ser eliminada.
     */
    @Override
    @Transactional
    public void eliminarPropiedad(Propiedad propiedad) {
        propiedadRepository.delete(propiedad);
    }

    /**
     * Encuentra y devuelve una propiedad especifica por su identificador unico.
     *
     * @param propiedad La propiedad con el identificador unico a buscar.
     * @return La propiedad encontrada o null si no existe.
     */
    @Override
    @Transactional(readOnly=true)
    public Propiedad encontrarPropiedad(Propiedad propiedad) {
        return propiedadRepository.findById(propiedad.getIdPropiedad()).orElse(null);
    }
}



package com.inmobiliaria.casaImperial.repository;


import org.springframework.data.repository.CrudRepository;
import com.inmobiliaria.casaImperial.domain.Mensaje;

/**
 * Interfaz de repositorio que extiende CrudRepository para la entidad Mensaje.
 * Proporciona operaciones CRUD basicas para la entidad Mensaje en la base de datos.
 */
public interface MensajeRepository extends CrudRepository<Mensaje, Long> {

}




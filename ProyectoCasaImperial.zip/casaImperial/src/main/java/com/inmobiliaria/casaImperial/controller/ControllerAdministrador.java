
package com.inmobiliaria.casaImperial.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.inmobiliaria.casaImperial.domain.Propiedad;
import com.inmobiliaria.casaImperial.domain.Vendedor;
import com.inmobiliaria.casaImperial.repository.PropiedadRepository;
import com.inmobiliaria.casaImperial.repository.VendedorRepository;
import com.inmobiliaria.casaImperial.service.MensajeService;
import com.inmobiliaria.casaImperial.service.PropiedadService;
import com.inmobiliaria.casaImperial.service.VendedorService;

import lombok.extern.slf4j.Slf4j;
/**
 * Clase controladora de URLs para la seccion del administrador.
 * Controla las operaciones relacionadas con la administracion, propiedades y vendedores.
 * @author JosephGutierrez
 */
@Controller
@Slf4j
public class ControllerAdministrador {
    
    /**
     * Objeto inyectado con Spring para obtener acceso a los servicios de VendedorService.
     * Autowired: Inyecta un bean de Spring en un controlador u otro bean.
     */
    @Autowired
    private VendedorService vendedorService;
    
    /**
     * Objeto inyectado con Spring para obtener acceso a los servicios de PropiedadService.
     * Autowired: Inyecta un bean de Spring en un controlador u otro bean.
     */
    @Autowired
    private PropiedadService propiedadService;

    /**
     * Controlador que maneja las solicitudes relacionadas con la seccion de administrador.
     * Este metodo responde a las solicitudes GET en la ruta "/admin" y muestra informacion sobre propiedades
     * y vendedores disponibles para el administrador.
     *
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara al administrador ("administrador").
     */
    @GetMapping("/admin")
    public String vAdmin(Model model) {
        // Obtiene la lista de propiedades desde el servicio de propiedades.
        List<Propiedad> propiedades = propiedadService.listarPropiedades();

        // Obtiene la lista de vendedores desde el servicio de vendedores.
        List<Vendedor> vendedores = vendedorService.listarVendedores();

        // Agrega la lista de vendedores y propiedades al modelo para su visualizacion en la vista.
        model.addAttribute("vendedores", vendedores);
        model.addAttribute("propiedades", propiedades);

        // Devuelve el nombre de la vista que se mostrara al administrador.
        return "administrador";
    }
}



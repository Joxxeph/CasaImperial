package com.inmobiliaria.casaImperial.service;

import java.util.List;

import com.inmobiliaria.casaImperial.domain.Propiedad;
import com.inmobiliaria.casaImperial.domain.Vendedor;
/**
 * Interfaz que define los metodos de servicio para la entidad Vendedor.
 * Proporciona operaciones relacionadas con la logica de negocio de los vendedores.
 */
public interface VendedorService {

    /**
     * Recupera y devuelve la lista de todos los vendedores almacenados en la base de datos.
     *
     * @return Lista de vendedores.
     */
    List<Vendedor> listarVendedores();

    /**
     * Guarda un nuevo vendedor en la base de datos o actualiza uno existente.
     *
     * @param vendedor El vendedor a ser guardado.
     */
    void guardarVendedor(Vendedor vendedor);

    /**
     * Elimina un vendedor de la base de datos.
     *
     * @param vendedor El vendedor a ser eliminado.
     */
    void eliminarVendedor(Vendedor vendedor);

    /**
     * Encuentra y devuelve un vendedor especifico por su identificador unico.
     *
     * @param vendedor El vendedor con el identificador unico a buscar.
     * @return El vendedor encontrado o null si no existe.
     */
    Vendedor encontrarVendedor(Vendedor vendedor);
}





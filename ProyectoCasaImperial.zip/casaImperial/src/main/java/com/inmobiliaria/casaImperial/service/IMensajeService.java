package com.inmobiliaria.casaImperial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inmobiliaria.casaImperial.domain.Mensaje;
import com.inmobiliaria.casaImperial.repository.MensajeRepository;


/**
 * Clase de servicio que implementa la interfaz MensajeService.
 * Proporciona logica de negocio para operaciones relacionadas con la entidad Mensaje.
 */
@Service
public class IMensajeService implements MensajeService {

    @Autowired
    private MensajeRepository mensajeRepository;

    /**
     * Recupera y devuelve la lista de todos los mensajes almacenados en la base de datos.
     *
     * @return Lista de mensajes.
     */
    @Override
    @Transactional(readOnly = true)
    public List<Mensaje> listarMensajes() {
        return (List<Mensaje>) mensajeRepository.findAll();
    }

    /**
     * Guarda un nuevo mensaje en la base de datos o actualiza uno existente.
     *
     * @param mensaje El mensaje a ser guardado.
     */
    @Override
    @Transactional
    public void guardarMensaje(Mensaje mensaje) {
        mensajeRepository.save(mensaje);
    }

    /**
     * Elimina un mensaje de la base de datos.
     *
     * @param mensaje El mensaje a ser eliminado.
     */
    @Override
    @Transactional
    public void eliminarMensaje(Mensaje mensaje) {
        mensajeRepository.delete(mensaje);
    }

    /**
     * Encuentra y devuelve un mensaje especifico por su identificador unico.
     *
     * @param mensaje El mensaje con el identificador unico a buscar.
     * @return El mensaje encontrado o null si no existe.
     */
    @Override
    @Transactional(readOnly = true)
    public Mensaje encontrarMensaje(Mensaje mensaje) {
        return mensajeRepository.findById(mensaje.getIdMensajeClt()).orElse(null);
    }
}
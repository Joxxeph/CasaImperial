

package com.inmobiliaria.casaImperial.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.inmobiliaria.casaImperial.domain.Mensaje;
import com.inmobiliaria.casaImperial.domain.Propiedad;
import com.inmobiliaria.casaImperial.domain.Vendedor;
import com.inmobiliaria.casaImperial.repository.PropiedadRepository;
import com.inmobiliaria.casaImperial.repository.VendedorRepository;
import com.inmobiliaria.casaImperial.service.MensajeService;
import com.inmobiliaria.casaImperial.service.PropiedadService;
import com.inmobiliaria.casaImperial.service.VendedorService;

import lombok.extern.slf4j.Slf4j;

/**
 * Clase controladora de URLs para la seccion de inicio y paginas generales.
 * Controla las operaciones relacionadas con la página de inicio, autorizacion, login, nosotros, contacto y manejo de errores.
 * @author JosephGutierrez
 */
@Controller
@Slf4j
public class ControllerHome {
    
    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private VendedorService vendedorService;

    @Autowired
    private PropiedadService propiedadService;

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/".
     * Muestra la página de inicio con la lista de propiedades disponibles.
     *
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en la pagina de inicio ("index").
     */
    @GetMapping("/")
    public String inicio(Model model) {
        List<Propiedad> propiedades = propiedadService.listarPropiedades();
        model.addAttribute("propiedades", propiedades);
        return "index";
    }

    

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/login".
     * Muestra el formulario de inicio de sesion.
     *
     * @return El nombre de la vista que se mostrara en el formulario de inicio de sesion ("login").
     */
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/nosotros".
     * Muestra la pagina "nosotros".
     *
     * @return El nombre de la vista que se mostrara en la pagina "nosotros".
     */
    @GetMapping("/nosotros")
    public String vNosotros() {
        return "nosotros";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/contacto".
     * Muestra la pagina de contacto con el formulario para enviar mensajes.
     *
     * @param mensaje Objeto Mensaje utilizado para recopilar la informacion del formulario.
     * @return El nombre de la vista que se mostrara en la pagina de contacto ("contacto").
     */
    @GetMapping("/contacto")
    public String vContacto(Mensaje mensaje) {
        return "contacto";
    }

    @Autowired
    private JavaMailSender javaMailSender;

    /**
     * Controlador que maneja las solicitudes POST en la ruta "/guardarMensaje".
     * Guarda el mensaje en la base de datos y envía una notificacion por correo electronico.
     *
     * @param mensaje Objeto Mensaje que contiene la informacion del formulario.
     * @param errores Objeto Errors para manejar posibles errores de validacion.
     * @return La redireccion a la pagina de contacto ("redirect:/contacto") despues de procesar el formulario.
     */
    @PostMapping("/guardarMensaje")
    public String guardarMensaje(@Valid Mensaje mensaje, Errors errores) {
        if (errores.hasErrors()) {
            return "/error";
        }

        SimpleMailMessage mensajeEnviar = new SimpleMailMessage();
        mensajeEnviar.setTo("casaimperialinmob@gmail.com");
        mensajeEnviar.setSubject("Nuevo mensaje de contacto: " + mensaje.getNombreClt());
        mensajeEnviar.setText("Detalles del mensaje:\n" +
                "Nombre: " + mensaje.getNombreClt() + "\n" +
                "Email: " + mensaje.getEmailClt() + "\n" +
                "Teléfono: " + mensaje.getTelefonoClt() + "\n" +
                "Mensaje: " + mensaje.getMensajeClt() + "\n" +
                "Interés: " + mensaje.getInteresClt() + "\n" +
                "Precio o presupuesto: " + mensaje.getPrecioPresupuestoClt() + "\n" +
                "Método de contacto: " + mensaje.getMetodoContactoClt() + "\n" + 
                "Fecha de contacto:" + mensaje.getFechaContactoClt() + "\n" + 
                "Hora de contacto: " + mensaje.getHoraContactoClt());

        javaMailSender.send(mensajeEnviar);

        mensajeService.guardarMensaje(mensaje);
        return "redirect:/contacto";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/error".
     * Muestra la página de manejo de errores.
     *
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en la pagina de manejo de errores ("error").
     */
    @GetMapping("/error")
    public String mostrarError(Model model) {
        return "error";
    }
}


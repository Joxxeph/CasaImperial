package com.inmobiliaria.casaImperial.service;

import java.util.List;
import java.util.Optional;

import com.inmobiliaria.casaImperial.domain.Propiedad;

/**
 * Interfaz que define los metodos de servicio para la entidad Propiedad.
 * Proporciona operaciones relacionadas con la logica de negocio de las propiedades.
 */
public interface PropiedadService {

    /**
     * Recupera y devuelve la lista de todas las propiedades almacenadas en la base de datos.
     *
     * @return Lista de propiedades.
     */
    List<Propiedad> listarPropiedades();

    /**
     * Guarda una nueva propiedad en la base de datos o actualiza una existente.
     *
     * @param propiedad La propiedad a ser guardada.
     */
    void guardarPropiedad(Propiedad propiedad);

    /**
     * Elimina una propiedad de la base de datos.
     *
     * @param propiedad La propiedad a ser eliminada.
     */
    void eliminarPropiedad(Propiedad propiedad);

    /**
     * Encuentra y devuelve una propiedad especifica por su identificador unico.
     *
     * @param propiedad La propiedad con el identificador unico a buscar.
     * @return La propiedad encontrada o null si no existe.
     */
    Propiedad encontrarPropiedad(Propiedad propiedad);
}
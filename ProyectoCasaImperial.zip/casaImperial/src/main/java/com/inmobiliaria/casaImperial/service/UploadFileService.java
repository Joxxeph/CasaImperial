package com.inmobiliaria.casaImperial.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


/**
 * Clase de servicio que proporciona metodos para el manejo de archivos, como guardar y eliminar imagenes.
 */
@Service
public class UploadFileService {

    private final String folder = "images//";

    /**
     * Guarda una imagen en la carpeta especificada y devuelve el nombre del archivo guardado.
     *
     * @param file La imagen a ser guardada.
     * @return El nombre del archivo guardado.
     * @throws IOException Si ocurre un error al leer o escribir el archivo.
     */
    public String saveImage(MultipartFile file) throws IOException {
        if (!file.isEmpty()) {
            byte[] bytes = file.getBytes();
            Path path = Paths.get(folder + file.getOriginalFilename());
            Files.write(path, bytes);
            return file.getOriginalFilename();
        }
        return "image-not-found.jpg";
    }

    /**
     * Elimina una imagen de la carpeta especificada.
     *
     * @param nombre El nombre del archivo a ser eliminado.
     */
    public void deleteImage(String nombre) {
        String ruta = "images//";
        File file = new File(ruta + nombre);
        file.delete();
    }
}


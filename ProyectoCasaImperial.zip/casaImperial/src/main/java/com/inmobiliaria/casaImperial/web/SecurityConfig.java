
package com.inmobiliaria.casaImperial.web;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.FormLoginConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Configuracion de seguridad para la aplicacion.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
	
	/**
     * Configuracion de usuarios en memoria.
     *
     * @return El servicio de detalles de usuario en memoria.
     */
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        manager.createUser(User.withUsername("admin").password(passwordEncoder().encode("CasaImperialAdministrador")).roles("USER", "ADMIN").build());
        return manager;
    }

    /**
     * Configuracion del encriptador de contraseñas.
     *
     * @return El encriptador de contraseñas BCrypt.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Configuracion general de seguridad.
     *
     * @param http La configuracion de seguridad HTTP.
     * @return La cadena de filtros de seguridad.
     * @throws Exception Si ocurre un error al configurar la seguridad.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeRequests(authorizeRequests -> 
                authorizeRequests
                    .requestMatchers("/", "/nosotros", "/propiedad/{idPropiedad}", "/propiedades", "/contacto").permitAll()
                    .requestMatchers("/admin", "/h2-console/**").authenticated()
                    .requestMatchers("/admin", "/admin/agregarPropiedad", "/admin/guardarPropiedad", "/editarPropiedad/{idPropiedad}",
                    		"/admin/agregarVendedor","/admin/guardarVendedor","/editarVendedor/{idVendedor}","/eliminarVendedor" ).hasRole("ADMIN")
            )
            .formLogin(formLogin -> formLogin
            		.loginPage("/login")
                    .defaultSuccessUrl("/admin", true)
                    .permitAll()
            )
            .csrf(AbstractHttpConfigurer::disable);
        return http.build();
    }
}







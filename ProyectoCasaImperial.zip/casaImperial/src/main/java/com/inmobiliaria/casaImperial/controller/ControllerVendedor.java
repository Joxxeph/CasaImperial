

package com.inmobiliaria.casaImperial.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.inmobiliaria.casaImperial.domain.Vendedor;
import com.inmobiliaria.casaImperial.repository.VendedorRepository;
import com.inmobiliaria.casaImperial.service.PropiedadService;
import com.inmobiliaria.casaImperial.service.VendedorService;

import lombok.extern.slf4j.Slf4j;

/**
 * Clase controladora de URLs para la seccion de vendedores.
 * Controla las operaciones relacionadas con la visualizacion, creacion, edicion y eliminacion de vendedores.
 * @author JosephGutierrez
 */
@Controller
@Slf4j
public class ControllerVendedor {

    @Autowired
    private VendedorService vendedorService;

    @Autowired
    private PropiedadService propiedadService;

    @Autowired
    private VendedorRepository vendedorRepository;

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/admin/agregarVendedor".
     * Muestra el formulario para agregar un nuevo vendedor.
     *
     * @param vendedor Objeto Vendedor utilizado para recopilar la informacion del formulario.
     * @return El nombre de la vista que se mostrara en el formulario de nuevo vendedor ("guardarVendedor").
     */
    @GetMapping("/admin/agregarVendedor")
    public String vCrearVendedor(Vendedor vendedor) {
        return "guardarVendedor";
    }

    /**
     * Controlador que maneja las solicitudes POST en la ruta "/admin/guardarVendedor".
     * Guarda un nuevo vendedor o actualiza uno existente.
     *
     * @param vendedor Objeto Vendedor que contiene la informacion del formulario.
     * @param errores Objeto Errors para manejar posibles errores de validacion.
     * @return La redirección a la pagina de administrador ("redirect:/admin") despues de procesar el formulario.
     */
    @PostMapping("/admin/guardarVendedor")
    public String guardarVendedor(@Valid Vendedor vendedor, Errors errores) {
        if (errores.hasErrors()) {
            return "/admin";
        }
        vendedorService.guardarVendedor(vendedor);
        return "redirect:/admin";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/editarVendedor/{idVendedor}".
     * Muestra el formulario para editar un vendedor existente.
     *
     * @param vendedor Objeto Vendedor que contiene la informacion del vendedor seleccionado para editar.
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en el formulario de edicion de vendedor ("guardarVendedor").
     */
    @GetMapping("/editarVendedor/{idVendedor}")
    public String editarVendedor(Vendedor vendedor, Model model) {
        vendedor = vendedorService.encontrarVendedor(vendedor);
        model.addAttribute("vendedor", vendedor);
        return "guardarVendedor";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/eliminarVendedor".
     * Elimina un vendedor existente.
     *
     * @param vendedor Objeto Vendedor que contiene la informacion del vendedor seleccionado para eliminar.
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return La redirección a la página de administrador ("redirect:/admin") despues de eliminar el vendedor.
     */
    @GetMapping("/eliminarVendedor")
    public String eliminarVendedor(Vendedor vendedor, Model model) {
        vendedorService.eliminarVendedor(vendedor);
        return "redirect:/admin";
    }
}



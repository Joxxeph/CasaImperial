package com.inmobiliaria.casaImperial.controller;



import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.inmobiliaria.casaImperial.domain.Propiedad;
import com.inmobiliaria.casaImperial.domain.Vendedor;
import com.inmobiliaria.casaImperial.repository.PropiedadRepository;
import com.inmobiliaria.casaImperial.repository.VendedorRepository;
import com.inmobiliaria.casaImperial.service.PropiedadService;
import com.inmobiliaria.casaImperial.service.UploadFileService;
import com.inmobiliaria.casaImperial.service.VendedorService;

import lombok.extern.slf4j.Slf4j;

/**
 * Clase controladora de URLs para la seccion de propiedades.
 * Controla las operaciones relacionadas con la visualizacion, creacion, edicion y eliminación de propiedades.
 * @author JosephGutierrez
 */
@Controller
@Slf4j
public class ControllerPropiedad {
    
    @Autowired
    private VendedorService vendedorService;

    @Autowired
    private UploadFileService upload;

    @Autowired
    private PropiedadService propiedadService;

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/propiedades".
     * Muestra la lista de todas las propiedades disponibles.
     *
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en la pagina de propiedades ("propiedades").
     */
    @GetMapping("/propiedades")
    public String vPropiedades(Model model) {
        List<Propiedad> propiedades = propiedadService.listarPropiedades();
        model.addAttribute("propiedades", propiedades);
        return "propiedades";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/propiedad/{idPropiedad}".
     * Muestra detalles especificos de una propiedad seleccionada.
     *
     * @param propiedad Objeto Propiedad que contiene la informacion de la propiedad seleccionada.
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en la pagina de propiedad ("propiedad").
     */
    @GetMapping("/propiedad/{idPropiedad}")
    public String vPropiedad(Propiedad propiedad, Model model) {
        propiedad = propiedadService.encontrarPropiedad(propiedad);
        model.addAttribute("propiedad", propiedad);
        return "propiedad";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/admin/agregarPropiedad".
     * Muestra el formulario para agregar una nueva propiedad.
     *
     * @param propiedad Objeto Propiedad utilizado para recopilar la informacion del formulario.
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en el formulario de nueva propiedad ("guardarPropiedad").
     */
    @GetMapping("/admin/agregarPropiedad")
    public String vCrearPropiedad(Propiedad propiedad, Model model) {
        List<Vendedor> vendedores = vendedorService.listarVendedores();
        model.addAttribute("vendedores", vendedores);
        return "guardarPropiedad";
    }

    /**
     * Controlador que maneja las solicitudes POST en la ruta "/admin/guardarPropiedad".
     * Guarda una nueva propiedad o actualiza una existente.
     *
     * @param propiedad Objeto Propiedad que contiene la informacion del formulario.
     * @param errores Objeto Errors para manejar posibles errores de validacion.
     * @return La redireccion a la pagina de administrador ("redirect:/admin") despues de procesar el formulario.
     * @throws IOException Si hay un error relacionado con la entrada/salida al trabajar con archivos.
     */
    @PostMapping("/admin/guardarPropiedad")
    public String guardarPropiedad(@Valid Propiedad propiedad,  Errors errores) throws IOException {
        if (errores.hasErrors()) {
            return "/error";
        }

        /*
        if(propiedad.getIdPropiedad()==null) {
            String imagen = upload.saveImage(file);
            propiedad.setImagenPrd(imagen);
        } else {
            if(file.isEmpty()) {
                Propiedad p = new Propiedad();
                p=propiedadService.encontrarPropiedad(propiedad);
                propiedad.setImagenPrd(p.getImagenPrd());
            } else {
                if(propiedad.getImagenPrd().equals("image-not-found.jpg")) {
                    upload.deleteImage(propiedad.getImagenPrd());
                }
                String nombreImagen=upload.saveImage(file);
                propiedad.setImagenPrd(nombreImagen);
            }
        }
        */

        propiedadService.guardarPropiedad(propiedad);

        return "redirect:/admin";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/editarPropiedad/{idPropiedad}".
     * Muestra el formulario para editar una propiedad existente.
     *
     * @param propiedad Objeto Propiedad que contiene la informacion de la propiedad seleccionada para editar.
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return El nombre de la vista que se mostrara en el formulario de edicion de propiedad ("guardarPropiedad").
     */
    @GetMapping("/editarPropiedad/{idPropiedad}")
    public String editarPropiedad(Propiedad propiedad, Model model) {
        propiedad = propiedadService.encontrarPropiedad(propiedad);
        model.addAttribute("propiedad", propiedad);
        List<Vendedor> vendedores = vendedorService.listarVendedores();
        model.addAttribute("vendedores", vendedores);
        return "guardarPropiedad";
    }

    /**
     * Controlador que maneja las solicitudes GET en la ruta "/eliminarPropiedad".
     * Elimina una propiedad existente.
     *
     * @param propiedad Objeto Propiedad que contiene la informacion de la propiedad seleccionada para eliminar.
     * @param model El modelo utilizado para pasar datos a la vista.
     * @return La redireccion a la pagina de administrador ("redirect:/admin") despues de eliminar la propiedad.
     */
    @GetMapping("/eliminarPropiedad")
    public String eliminarPropiedad(Propiedad propiedad, Model model) {
        /*
        if(propiedad.getImagenPrd().equals("image-not-found.jpg")) {
            upload.deleteImage(propiedad.getImagenPrd());
        }
        */

        propiedadService.eliminarPropiedad(propiedad);
        return "redirect:/admin";
    }
}




package com.inmobiliaria.casaImperial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inmobiliaria.casaImperial.domain.Propiedad;
import com.inmobiliaria.casaImperial.domain.Vendedor;
import com.inmobiliaria.casaImperial.repository.PropiedadRepository;
import com.inmobiliaria.casaImperial.repository.VendedorRepository;
/**
 * Clase de servicio que implementa la interfaz VendedorService.
 * Proporciona logica de negocio para operaciones relacionadas con la entidad Vendedor.
 */
@Service
public class IVendedorService implements VendedorService {

    @Autowired
    private VendedorRepository vendedorRepository;

    @Autowired
    private PropiedadRepository propiedadRepository;

    /**
     * Recupera y devuelve la lista de todos los vendedores almacenados en la base de datos.
     *
     * @return Lista de vendedores.
     */
    @Override
    @Transactional(readOnly=true)
    public List<Vendedor> listarVendedores() {
        return (List<Vendedor>) vendedorRepository.findAll();
    }

    /**
     * Guarda un nuevo vendedor en la base de datos o actualiza uno existente.
     *
     * @param vendedor El vendedor a ser guardado.
     */
    @Override
    @Transactional
    public void guardarVendedor(Vendedor vendedor) {
        vendedorRepository.save(vendedor);
    }

    /**
     * Elimina un vendedor de la base de datos.
     *
     * @param vendedor El vendedor a ser eliminado.
     */
    @Override
    @Transactional
    public void eliminarVendedor(Vendedor vendedor) {
        vendedorRepository.delete(vendedor);
    }

    /**
     * Encuentra y devuelve un vendedor especifico por su identificador unico.
     *
     * @param vendedor El vendedor con el identificador unico a buscar.
     * @return El vendedor encontrado o null si no existe.
     */
    @Override
    @Transactional(readOnly=true)
    public Vendedor encontrarVendedor(Vendedor vendedor) {
        return vendedorRepository.findById(vendedor.getIdVendedor()).orElse(null);
    }
}





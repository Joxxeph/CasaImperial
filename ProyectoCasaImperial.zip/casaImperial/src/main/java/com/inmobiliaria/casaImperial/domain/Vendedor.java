package com.inmobiliaria.casaImperial.domain;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Clase de entidad que representa un vendedor.
 * Anotada con las anotaciones de Lombok (@Data) para la generacion automatica de metodos getter, setter, toString, equals, y hashCode.
 * Anotada con JPA para la persistencia en la base de datos.
 * Implementa la interfaz Serializable para soportar la serializacion.
 */
@Data
@Entity 
@Table (name="vendedor")
public class Vendedor implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idVendedor;
	
	@NotEmpty
	private String primerNombreVdr;
	
	
	private String segundoNombreVdr;
	

	@NotEmpty
	private String primerApellidoVdr;
	
	@NotEmpty
	private String segundoApellidoVdr;
	

	@NotNull
	private String telefonoVdr;
	
	@NotEmpty
	@Email
	private String emailVdr; 
	

}



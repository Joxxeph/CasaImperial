

package com.inmobiliaria.casaImperial.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.inmobiliaria.casaImperial.domain.Vendedor;


/**
 * Interfaz de repositorio que extiende JpaRepository para la entidad Vendedor.
 * Proporciona operaciones CRUD básicas y operaciones adicionales para la entidad Vendedor en la base de datos.
 */
public interface VendedorRepository extends JpaRepository<Vendedor, Long>{

	
}





package com.inmobiliaria.casaImperial.service;

import java.util.List;

import com.inmobiliaria.casaImperial.domain.Mensaje;
/**
 * Interfaz que define los metodos de servicio para la entidad Mensaje.
 * Proporciona operaciones relacionadas con la logica de negocio de los mensajes.
 */
public interface MensajeService {

    /**
     * Recupera y devuelve la lista de todos los mensajes almacenados en la base de datos.
     *
     * @return Lista de mensajes.
     */
    List<Mensaje> listarMensajes();

    /**
     * Guarda un nuevo mensaje en la base de datos o actualiza uno existente.
     *
     * @param mensaje El mensaje a ser guardado.
     */
    void guardarMensaje(Mensaje mensaje);

    /**
     * Elimina un mensaje de la base de datos.
     *
     * @param mensaje El mensaje a ser eliminado.
     */
    void eliminarMensaje(Mensaje mensaje);

    /**
     * Encuentra y devuelve un mensaje especifico por su identificador unico.
     *
     * @param mensaje El mensaje con el identificador unico a buscar.
     * @return El mensaje encontrado o null si no existe.
     */
    Mensaje encontrarMensaje(Mensaje mensaje);
}

